package com.example.travelexpertsgo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.renderscript.Type;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CustomerActivity extends AppCompatActivity {
    private TextView txtCustFirstName;
    private TextView txtCustLastName;
    private TextView txtCustAddress;
    private TextView txtCustCity;
    private TextView txtCustProv;
    private TextView txtCustPostal;
    private TextView txtCustCountry;
    private TextView txtCustHPhone;
    private TextView txtCustBPhone;
    private TextView txtCustEmail;
    private Button btnModify;
    private Button btnSubmit;

    private CustomerAPI customerAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);


        txtCustFirstName = findViewById(R.id.etFirstName);
        txtCustLastName = findViewById(R.id.etLastName);
        txtCustAddress = findViewById(R.id.etAddress);
        txtCustCity = findViewById(R.id.etCity);
        txtCustProv = findViewById(R.id.etProv);
        txtCustPostal = findViewById(R.id.etPostal);
        txtCustCountry = findViewById(R.id.etCountry);
        txtCustHPhone = findViewById(R.id.etHPhone);
        txtCustBPhone = findViewById(R.id.etBPhone);
        txtCustEmail = findViewById(R.id.etEmail);
        btnModify = findViewById(R.id.btnModify);
        btnSubmit = findViewById(R.id.btnSubmit);

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(" http://10.163.37.222:8080/travelExpertsREST/rs/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build();

        customerAPI = retrofit.create(CustomerAPI.class);

        getCustomer();
        // getComments();
        // createPost();
        // updatePost();
        // deletePost();
    }

    private void getCustomer () {

        int userId = getIntent().getIntExtra("USER_ID", 0);

        Call<Customer> call = customerAPI.getCustomer(userId);

        call.enqueue(new Callback<Customer>() {
            @Override
            public void onResponse(Call<Customer> call, Response<Customer> response) {
                if (!response.isSuccessful()) {
                    //textViewResult.setText("Code: " + response.code());
                    return;
                }

                Customer customer = response.body();

                    txtCustFirstName.setText(customer.getCustFirstName());
                    txtCustLastName.setText(customer.getCustLastName());
                    txtCustAddress.setText(customer.getCustAddress());
                    txtCustCity.setText(customer.getCustCity());
                    txtCustProv.setText(customer.getCustProv());
                    txtCustPostal.setText(customer.getCustPostal());
                    txtCustCountry.setText(customer.getCustCountry());
                    txtCustHPhone.setText(customer.getCustHPhone());
                    txtCustBPhone.setText(customer.getCustBPhone());
                    txtCustEmail.setText(customer.getCustEmail());
            }

            @Override
            public void onFailure(Call<Customer> call, Throwable t) {
                txtCustFirstName.setText(t.getMessage());
            }
        });
    }

    public void updateCustomer(View view) {
        final int userId = getIntent().getIntExtra("USER_ID", 0);

        Customer customer = new Customer(userId,
                txtCustFirstName.getText().toString(),
                txtCustLastName.getText().toString(),
                txtCustAddress.getText().toString(),
                txtCustCity.getText().toString(),
                txtCustProv.getText().toString(),
                txtCustPostal.getText().toString(),
                txtCustCountry.getText().toString(),
                txtCustHPhone.getText().toString(),
                txtCustBPhone.getText().toString(),
                txtCustEmail.getText().toString());

        JSONObject jsonString = new JSONObject();
        try {
            jsonString.put("customerId", userId);
            jsonString.put("custAddress", txtCustAddress.getText().toString());
            jsonString.put("custBusPhone", txtCustBPhone.getText().toString());
            jsonString.put("custCity", txtCustCity.getText().toString());
            jsonString.put("custCountry", txtCustCountry.getText().toString());
            jsonString.put("custEmail", txtCustEmail.getText().toString());
            jsonString.put("custFirstName", txtCustFirstName.getText().toString());
            jsonString.put("custLastName", txtCustLastName.getText().toString());
            jsonString.put("custHomePhone", txtCustHPhone.getText().toString());
            jsonString.put("custPostal", txtCustPostal.getText().toString());
            jsonString.put("custProv", txtCustProv.getText().toString());
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        Log.d("test",jsonString.toString());
        Call<Customer> call = customerAPI.postCustomer(customer);
        call.enqueue(new Callback<Customer>() {
            @Override
            public void onResponse(Call<Customer> call, Response<Customer> response) {
                if (!response.isSuccessful()) {
                    //textViewResult.setText("Code: " + response.code());
                    return;
                }

                Customer custResponse = response.body();

            }

            @Override
            public void onFailure(Call<Customer> call, Throwable t) {
                //txtCustFirstName.setText(t.getMessage());
            }
        });

        txtCustFirstName.setEnabled(false);
        txtCustLastName.setEnabled(false);
        txtCustAddress.setEnabled(false);
        txtCustCity.setEnabled(false);
        txtCustProv.setEnabled(false);
        txtCustPostal.setEnabled(false);
        txtCustCountry.setEnabled(false);
        txtCustHPhone.setEnabled(false);
        txtCustBPhone.setEnabled(false);
        txtCustEmail.setEnabled(false);
        btnModify.setEnabled(true);
        btnSubmit.setEnabled(false);
    }

    public void modifyData(View view) {
        txtCustFirstName.setEnabled(true);
        txtCustLastName.setEnabled(true);
        txtCustAddress.setEnabled(true);
        txtCustCity.setEnabled(true);
        txtCustProv.setEnabled(true);
        txtCustPostal.setEnabled(true);
        txtCustCountry.setEnabled(true);
        txtCustHPhone.setEnabled(true);
        txtCustBPhone.setEnabled(true);
        txtCustEmail.setEnabled(true);
        btnModify.setEnabled(false);
        btnSubmit.setEnabled(true);
    }
}
