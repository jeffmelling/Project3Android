package com.example.travelexpertsgo;

import com.google.gson.annotations.SerializedName;

public class Customer {
    private int customerId;
    private String custFirstName;
    private String custLastName;
    private String custAddress;
    private String custCity;
    private String custProv;
    private String custPostal;
    private String custCountry;

    @SerializedName("custHomePhone")
    private String custHPhone;

    @SerializedName("custBusPhone")
    private String custBPhone;

    private String custEmail;

    public Customer(int customerId) {
        this.customerId = customerId;
    }

    public Customer(int customerId, String custFirstName, String custLastName, String custAddress, String custCity, String custProv, String custPostal, String custCountry, String custHPhone, String custBPhone, String custEmail) {
        this.customerId = customerId;
        this.custFirstName = custFirstName;
        this.custLastName = custLastName;
        this.custAddress = custAddress;
        this.custCity = custCity;
        this.custProv = custProv;
        this.custPostal = custPostal;
        this.custCountry = custCountry;
        this.custHPhone = custHPhone;
        this.custBPhone = custBPhone;
        this.custEmail = custEmail;
    }

    public int getCustomerId() {
        return customerId; }

    public String getCustFirstName() {
        return custFirstName; }

    public String getCustLastName() {
        return custLastName; }

    public String getCustAddress() {
        return custAddress;}

    public String getCustCity() {
        return custCity; }

    public String getCustProv() {
        return custProv; }

    public String getCustPostal() {
        return custPostal; }

    public String getCustCountry() {
        return custCountry; }

    public String getCustHPhone() {
        return custHPhone; }

    public String getCustBPhone() {
        return custBPhone; }

    public String getCustEmail() {
        return custEmail; }
}
