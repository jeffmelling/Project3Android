package com.example.travelexpertsgo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.travelexpertsgo.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    public static final String EXTRA_MESSAGE = "com.example.android.twoactivities.extra.MESSAGE";
    public static final int TEXT_REQUEST = 1;
    private TextView txtHeader;
    private TextView txtAccount;
    private TextView txtPackage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialize all the view variables
        txtHeader = findViewById(R.id.txtHeader);
        txtAccount = findViewById(R.id.txtAccount);
        txtPackage = findViewById(R.id.txtPackage);

        Log.d(LOG_TAG, "-------");
        Log.d(LOG_TAG, "onCreate");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }

    public void launchCustomerActivity(View view) {
        Log.d(LOG_TAG, "Button clicked");
        // Receive login data
        int userId = getIntent().getIntExtra("USER_ID", 0);
        Intent intent = new Intent(this, CustomerActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    public void launchPackageActivity(View view) {
        Log.d(LOG_TAG, "Button clicked");
        Intent intent = new Intent(this, PackageActivity.class);
        startActivity(intent);
    }

    public void LogOutActivity(View view) {
        Log.d(LOG_TAG, "Button clicked");
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}
