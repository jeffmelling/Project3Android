package com.example.travelexpertsgo;

public class Package {
    private int packageId;
    private String pkgName;
    private String pkgStartDate;
    private String pkgEndDate;
    private String pkgDesc;
    private double pkgBasePrice;
    private double pkgAgencyCommission;
    private String image;

    public int getPackageId() {
        return packageId; }

    public String getPkgName() {
        return pkgName; }

    public String getPkgStartDate() {
        return pkgStartDate; }

    public String getPkgEndDate() {
        return pkgEndDate; }

    public String getPkgDesc() {
        return pkgDesc; }

    public double getPkgBasePrice() {
        return pkgBasePrice; }

    public double getPkgAgencyCommission() {
        return pkgAgencyCommission; }

    public String getImage() {
        return image; }
}
